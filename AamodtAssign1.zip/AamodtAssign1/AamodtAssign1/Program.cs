﻿/* Nathan Aamodt   
 * Systems Programming
 * Assign 1
 * Gamradt
 * This program will take symbol inputs from symbol.dat and create a symbol table 
 * using a bianary search tree and allow for searching of stored symbols.
 * */
using AamodtAssign1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AamodtAssign1
{
    class Program
    {
        /*Main
         * This function will create the list/table,
         * Call in the search method to search,
         * and call in the view method to list the table.
         */
        static void Main()
        {
            string path = System.IO.Directory.GetCurrentDirectory();
            path = path + "\\AamodtAssign1\\";
            BianarySTree testTree = new BianarySTree();
            testTree.ReadFile(path +"SYMBOLS.DAT");

            testTree.Org();

            testTree.ViewSym();


            testTree.filetwo();





        }
    }
}
