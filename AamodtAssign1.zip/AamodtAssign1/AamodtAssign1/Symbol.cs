﻿/* Nathan Aamodt   
 * Systems Programming
 * Assign 1
 * Gamradt
 * This program will take symbol inputs from symbol.dat and create a symbol table 
 * using a bianary search tree and allow for searching of stored symbols.
 * */
using AamodtAssign1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AamodtAssign1
{
    public class Symbol
    {
        public string Sym { get; set; }
        public int RF { get; set; }
        public int Value { get; set; }
        public int MF { get; set; }
        public Symbol Right { get; set; }
        public Symbol Left { get; set; }

        /*
         * Symbol
         * This function sets up the table with all the entities it needs for each entry
         * Inputs: None
         * doesnt output anything but is used to create the whole list
         */
        public Symbol()
        {
            Sym = null;
            RF = 0;
            Value = 0;
            MF = 0;
            Right = null;
            Left = null;
        }
        /*
 * Symbol
 * This function sets up the table with all the entities it needs for each entry
 * Inputs are other symbol method having it named to create a copy of it
 * doesnt output anything but is used to create the whole list
 */
        public Symbol (string symbol, int Rval, int val)
        {
            Sym = symbol;
            RF = Rval;
            Value = val;
            MF = 0;
            Right = null;
            Left = null;
        }
    }
}