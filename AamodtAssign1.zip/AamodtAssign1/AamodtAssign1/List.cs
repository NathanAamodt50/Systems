﻿/* Nathan Aamodt   
 * Systems Programming
 * Assign 1
 * Gamradt
 * This program will take symbol inputs from symbol.dat and create a symbol table 
 * using a bianary search tree and allow for searching of stored symbols.
 * */
using AamodtAssign1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AamodtAssign1
{
    //Class List
    //this class opens the symbols file, then it procceeds to initalize the table and fill the table with the inputed symbols
    //from the  file.
    
    public class BianarySTree
    {
        List<Symbol> Input = new List<Symbol>();
        public static int Number = 0;
        public Symbol Root { get; set; }


        //List() defines the table as well as calls in the functions we need to complete the table.
        // no inputs
        // no outputs
        public BianarySTree()
        {
            Root = null;

        }
        //List
        //copy constructor of List
        //Uses the input of the copy constructor for symbol
        public BianarySTree(Symbol Soul)
        {
            Root = Soul;

        }

        public IEnumerable<Symbol> GetTab(Symbol L)
        {
            int n = 0;
            int TableVal = 0;

            if(Number > 0)
            {
                do
                { 
                    if (String.Compare(L.Sym, Input[TableVal].Sym) == 0)
                    {
                    n = 1;
                    //Input[TableVal].MF = 1;
                    Console.WriteLine("Multiple Symbol");
                    Input[TableVal].MF = 1;
                        TableVal = Number + 1;
                    }

                TableVal++;
                } while (TableVal < Number);
            }



            if(n ==0)
            {
            Input.Add(L);
            Console.WriteLine(L.Sym + "\t" + L.Value + "\t" + L.RF + "\t" + L.MF + "\t< ---Symbol Added");
                Number = Number + 1;
            }

            return Input;
        }
        /*
        * Create List ~ This function will create the table using inputs from the user for symbols, R&M Flags, and value
        * Will then insert symbols into the array of symbols to later be listed and searched from using the Bianary search tree.
        * No inputs, does most of the table creation and finding multiple values
        */
        public void ReadFile(string File)
        {

            string symname = null;
            int valnum = 0;
            int Rflag = 0;
            string[] line;
            Console.WriteLine("Symbol\tValue\tRflag\tMflag");
            StreamReader Fin = new StreamReader(File);
            string words = Fin.ReadLine();

            while (words != null)
            {
                string RF;
                line = words.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                symname = line[0];
                RF = line[1];

                if (line[2].Length > 3)
                {
                    valnum = 101;
                }
                else
                {
                  valnum = Convert.ToInt32(line[2]);
                }    
                    
                        
                    
                
                
                

                
                
                //switch statement for RFlag so it can take in any input of true or false
                switch (RF)
                {
                    case "T":
                        {
                            Rflag = 1;
                        }
                        break;
                    case "F":
                        {
                            Rflag = 0;
                        }
                        break;
                    case "0":
                        {
                            Rflag = 0;
                        }
                        break;
                    case "1":
                        {
                            Rflag = 1;
                        }
                        break;
                    case "True":
                        {
                            Rflag = 1;
                        }
                        break;
                    case "False":
                        {
                            Rflag = 0;
                        }
                        break;
                    case "true":
                        {
                            Rflag = 1;
                        }
                        break;
                    case "false":
                        {
                            Rflag = 0;
                        }
                        break;
                    default:
                        {
                            Rflag = 0;
                        }
                        break;

                }
                if(valnum != 101)
                {
                Symbol newinput = new Symbol(symname, Rflag, valnum);
                createTable(newinput);
                }
                else { }

                words = Fin.ReadLine();
                
                //Console.WriteLine(words);
            }
            Fin.Close();
            

        }


        public int TestInput(string symbol)
        {
            int val;
            if (symbol.Length > 21)
            {
                //Console.WriteLine("Error 1");
                val = 0;
                return val;
            }
            else if (Char.IsDigit(symbol[0]))
            {
               // Console.WriteLine("Error 2");
                val = 0;
                return val;
            }
            foreach (char tempChar in symbol)
            {
                if (Char.IsLetterOrDigit(tempChar) && tempChar != '_')
                {
                    val = 1;
                    return val;
                }
                else
                {
                    val = 0;
                    return val;
                }
            }
            //Console.WriteLine("Error 3");
            val = 0;
            return val;
        }
        public string symcut(string symbol)
        {
            if (symbol.Length > 6)
            {
                //Console.WriteLine("here");
                return symbol.Substring(0, 6);

            }
            else
            {
                
                return symbol;
            }

        }
        public void createTable(Symbol L)
        {
            Symbol newl = L;
 

                if (TestInput(newl.Sym) == 0)
                {
                    Console.WriteLine("Symbol Is Invalid");
                    
                }
               else
               {
                    newl.Sym = symcut(newl.Sym);
                    GetTab(newl);
               }

        }


/* Void filetwo
 * This will ask the user for what test file they want to use and read it and search for matches throughout the table
 */
        public void filetwo()
        {
            string filename, Test;
            string path = System.IO.Directory.GetCurrentDirectory();
            path = path + "\\AamodtAssign1\\";
            Console.WriteLine("Please Input the Test File Name");
            filename = Console.ReadLine();
            int valid = 0;
            

            StreamReader compare = new StreamReader(path+filename);
            Test = compare.ReadLine();
            Console.WriteLine("\t\t\tSymbol\tValue\tRflag\tMflag");
            while(Test != null)
            {
                
                valid = TestInput(Test);
                
                if(valid ==0)
                {
                    Console.WriteLine("Symbol Is Invalid:" + Test);
                }
                else
                {
                    Test = symcut(Test);
                     BST(Test);
                }



                Test = compare.ReadLine();
            }
        }
        /* Void BST
         * This will take the test symbol and search for it.
         * It will then return a 1 and print the found data if the value is found.
         * If not found then it will return a 0 and Say it is not found.
         */
        public void BST   (string test)
        {
            int i = Number / 2;
            int j = Number /2;
            int done = 0;
            //Console.WriteLine(String.Compare(test, Input[j].Sym));
            //test = test + ":";
            //if tree needs to search to the right
            if (String.Compare(test, Input[j].Sym) > 0)
            {

                while (done == 0)
                    {
                        Input[i].Right = Input[i - 1];
                        if (String.Compare(test, Input[i].Right.Sym) < 0)
                        {
                            Console.WriteLine("Symbol: " + test + "\t" + "Not Found");
                        done = 1;
                        }

                        else if (String.Compare(test, Input[i].Right.Sym) > 0)
                        {
                       // Console.WriteLine("Why Right");
                        
                            i--;
                        }

                        else if (test == Input[i].Right.Sym)
                        {
                            Console.WriteLine("Symbol Found ----->" + "\t" + Input[i].Right.Sym + "\t" + Input[i].Right.Value + "\t" + Input[i].Right.RF + "\t" + Input[i].Right.MF);
                        done = 1;
                        }

                    }
                

            }
            else if(String.Compare(test, Input[j].Sym) < 0)
            {

                while (done==0)
                {
                   Input[i].Left = Input[i + 1];
                    
                        if (String.Compare(test, Input[i].Left.Sym) < 0)
                        {
                       // Console.WriteLine("Why Left");
                        
                        i++;
                        }
                       else if (String.Compare(test, Input[i].Left.Sym) > 0)
                       {
                          Console.WriteLine("Symbol: " + test + "\t" + "Not Found");
                        done = 1;

                       }
                       else if (test == Input[i].Left.Sym)
                       {
                           Console.WriteLine("Symbol Found ----->" + "\t" + Input[i].Left.Sym + "\t" + Input[i].Left.Value + "\t" + Input[i].Left.RF + "\t" + Input[i].Left.MF);
                        done = 1;
                       }

                }
            }
            
        }

     


        public  void ViewSym()
        {
            Console.WriteLine("Symbol" + "\t" + "Value" + "\t" + "RFlag" + "\t" + "MFlag");
            for (int i = 0; i < Input.Count; i++)
            {
                if (Input[i].Sym == "")
                {

                }
                else
                {
                    if (i == 5 || i == 10 || i == 15 || i == 20 || i == 25 || i == 30)
                    {
                        Console.WriteLine("Press a key to continue!");
                        Console.ReadKey(true);
                        Console.WriteLine(Input[i].Sym + "\t" + Input[i].Value + "\t" + Input[i].RF + "\t" + Input[i].MF);
                    }
                    else
                    {
                        Console.WriteLine(Input[i].Sym + "\t" + Input[i].Value + "\t" + Input[i].RF + "\t" + Input[i].MF);
                    }
                }
            }


        }


        public void Org()
        {
            
            Symbol temp = null;
            for (int i=0; i < Number; i++)
            {
                for (int j=0; j < Number; j++)
                {
                if (String.Compare(Input[i].Sym, Input[j].Sym) < 0)
                {

                }
                else if (String.Compare(Input[i].Sym, Input[j].Sym) > 0)
                {
                    temp = Input[j];
                    Input[j] = Input[i];
                    Input[i] = temp;
                }
                else
                {

                }

                }


                
            }
        }
    }
}
